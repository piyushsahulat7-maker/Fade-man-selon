FADE MEN'S SALON — REAL PHOTO SETUP

1. Upload this HTML file as index.html in your GitHub repository.
2. Create a folder named photos next to index.html.
3. Add the salon's actual photos with these exact filenames:
   - salon-hero.jpg (front/interior hero photo)
   - salon-chair.jpg (barber chair or real haircut photo)
   - fade-haircut.jpg (real fade haircut)
   - salon-interior.jpg (real salon interior)
   - beard-grooming.jpg (real beard grooming)
   - hair-styling.jpg (real hair styling)
   - barber-tools.jpg (real barber tools)
4. These must be the owner's real salon photos, not sample or stock photos. Until photos are added, the page displays a labelled photo placeholder.

Saved address: M R Arcade, Vamadapadav, Chennaithodi, Karnataka 574324
Instagram: https://www.instagram.com/fade_mens_salon/
